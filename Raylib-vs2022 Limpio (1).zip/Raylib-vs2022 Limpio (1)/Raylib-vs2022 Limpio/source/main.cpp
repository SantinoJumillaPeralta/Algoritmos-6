﻿#include "raylib.h"
#include <vector>
#include <memory>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <algorithm>
#include <string>
#include <sstream>
#include <iostream>

constexpr int SCREEN_W = 800;
constexpr int SCREEN_H = 600;
constexpr float GRAVITY = 500.0f;
constexpr float GROUND_HEIGHT = 72.0f;
constexpr float OUT_MARGIN = 300.0f;
constexpr int MAX_PROJECTILES = 6;

static inline int RandInt(int a, int b) {
    return GetRandomValue(a, b);
}
static inline float RandFloat(float a, float b) {
    if (a == b) return a;
    return a + (b - a) * (float)rand() / (float)RAND_MAX;
}
static inline float F(float v) { return v; }

static bool CircleRectColl(const Vector2& c, float r, const Rectangle& rect) {
    float closestX = fmax(rect.x, fmin(c.x, rect.x + rect.width));
    float closestY = fmax(rect.y, fmin(c.y, rect.y + rect.height));
    float dx = c.x - closestX;
    float dy = c.y - closestY;
    return (dx * dx + dy * dy) <= r * r;
}

static bool CircleCircleColl(const Vector2& a, float ra, const Vector2& b, float rb) {
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    return (dx * dx + dy * dy) <= (ra + rb) * (ra + rb);
}

struct Projectile {
    Vector2 pos;
    Vector2 vel;
    float radius;
    bool active;
    Projectile() : pos{ 0,0 }, vel{ 0,0 }, radius(8.0f), active(false) {}

    void Fire(const Vector2& start, float angleDeg, float power) {
        pos = start;
        float a = angleDeg * DEG2RAD;
        vel.x = power * cosf(a);
        vel.y = -power * sinf(a);
        active = true;
    }

    void Update(float dt) {
        if (!active) return;
        vel.y += GRAVITY * dt;
        pos.x += vel.x * dt;
        pos.y += vel.y * dt;
        if (pos.x < -OUT_MARGIN || pos.x > SCREEN_W + OUT_MARGIN ||
            pos.y > SCREEN_H + OUT_MARGIN || pos.y < -OUT_MARGIN) active = false;
    }

    void Draw(const Texture2D& projTex) const {
        if (!active) return;
        if (projTex.id != 0) {
            float size = radius * 2.0f;
            Rectangle src = { 0.0f, 0.0f, (float)projTex.width, (float)projTex.height };
            Rectangle dest = { pos.x - size * 0.5f, pos.y - size * 0.5f, size, size };
            Vector2 origin = { size * 0.5f, size * 0.5f };
            float rot = atan2f(-vel.y, vel.x) * RAD2DEG;
            DrawTexturePro(projTex, src, dest, origin, rot, WHITE);
        }
        else {
            DrawCircleV(pos, radius, RED);
        }
    }
};

struct EnemyBase {
    bool alive;
    bool escaped;
    EnemyBase() : alive(true), escaped(false) {}
    virtual ~EnemyBase() = default;
    virtual void Update(float dt) = 0;
    virtual void Draw(const Texture2D& tex) const = 0;
    virtual bool CheckCollision(const Projectile& p) const = 0;
    virtual bool OutOfBoundsLeft() const = 0;
    virtual bool IsCompletelyOffscreen() const = 0;
    virtual Color DebugColor() const = 0;
};

struct EnemyRect : EnemyBase {
    Vector2 pos;
    Vector2 vel;
    Rectangle rect;
    Color color;
    EnemyRect() : pos{ 0,0 }, vel{ 0,0 }, rect{ 0,0,0,0 }, color(BLACK) {}
    void Update(float dt) override {
        pos.x += vel.x * dt;
        pos.y += vel.y * dt;
        rect.x = pos.x - rect.width * 0.5f;
        rect.y = pos.y - rect.height * 0.5f;
    }
    void Draw(const Texture2D& tex) const override {
        if (!alive) return;
        if (tex.id != 0) {
            Rectangle src = { 0.0f,0.0f,(float)tex.width,(float)tex.height };
            Rectangle dest = { rect.x, rect.y, rect.width, rect.height };
            Vector2 origin = { 0.0f,0.0f };
            DrawTexturePro(tex, src, dest, origin, 0.0f, WHITE);
        }
        else {
            DrawRectangleRec(rect, color);
        }
    }
    bool CheckCollision(const Projectile& p) const override {
        return CircleRectColl(p.pos, p.radius, rect);
    }
    bool OutOfBoundsLeft() const override {
        return (rect.x + rect.width) < 0.0f;
    }
    bool IsCompletelyOffscreen() const override {
        return (rect.x + rect.width) < -OUT_MARGIN ||
            rect.x > SCREEN_W + OUT_MARGIN ||
            rect.y + rect.height < -OUT_MARGIN ||
            rect.y > SCREEN_H + OUT_MARGIN;
    }
    Color DebugColor() const override { return color; }
};

struct EnemyCircle : EnemyBase {
    Vector2 pos;
    Vector2 vel;
    float radius;
    float restitution;
    Color color;
    EnemyCircle() : pos{ 0,0 }, vel{ 0,0 }, radius(16.0f), restitution(0.75f), color(BLACK) {}
    virtual void Update(float dt) override {
        vel.y += GRAVITY * dt;
        pos.x += vel.x * dt;
        pos.y += vel.y * dt;

        float groundY = (float)SCREEN_H - GROUND_HEIGHT;
        if (pos.y + radius >= groundY) {
            pos.y = groundY - radius;
            vel.y = -vel.y * restitution;
            vel.x *= 0.99f;
            if (fabs(vel.y) < 6.0f) vel.y = 0.0f;
        }

        if (pos.x - radius <= 0.0f) {
            pos.x = radius;
            vel.x = -vel.x * 0.90f;
        }
        else if (pos.x + radius >= SCREEN_W) {
            pos.x = SCREEN_W - radius;
            vel.x = -vel.x * 0.90f;
        }

        if (pos.y - radius < 0.0f) {
            pos.y = radius;
            vel.y = -vel.y * restitution * 0.8f;
        }
    }
    void Draw(const Texture2D& tex) const override {
        if (!alive) return;
        if (tex.id != 0) {
            float size = radius * 2.0f;
            Rectangle src = { 0.0f,0.0f,(float)tex.width,(float)tex.height };
            Rectangle dest = { pos.x - size * 0.5f, pos.y - size * 0.5f, size, size };
            Vector2 origin = { 0.0f,0.0f };
            DrawTexturePro(tex, src, dest, origin, 0.0f, WHITE);
        }
        else {
            DrawCircleV(pos, radius, color);
        }
    }
    bool CheckCollision(const Projectile& p) const override {
        return CircleCircleColl(p.pos, p.radius, pos, radius);
    }
    bool OutOfBoundsLeft() const override {
        return (pos.x + radius) < 0.0f;
    }
    bool IsCompletelyOffscreen() const override {
        return (pos.x + radius) < -OUT_MARGIN ||
            pos.x - radius > SCREEN_W + OUT_MARGIN ||
            pos.y - radius > SCREEN_H + OUT_MARGIN ||
            pos.y + radius < -OUT_MARGIN;
    }
    Color DebugColor() const override { return color; }
};

struct EnemyFall : EnemyCircle {
    EnemyFall() : EnemyCircle() {}
    void Update(float dt) override {
        vel.y += GRAVITY * dt;
        pos.x += vel.x * dt;
        pos.y += vel.y * dt;
    }
    bool OutOfBoundsLeft() const override {
        return (pos.x + radius) < 0.0f;
    }
    bool IsCompletelyOffscreen() const override {
        return pos.y - radius > SCREEN_H + OUT_MARGIN ||
            (pos.x + radius) < -OUT_MARGIN ||
            pos.x - radius > SCREEN_W + OUT_MARGIN;
    }
};

static Texture2D LoadTextureWithFallback(const std::string& primaryPath) {
    auto tryLoad = [&](const std::string& p) -> Texture2D {
        Texture2D t = LoadTexture(p.c_str());
        return t;
        };

    size_t pos = primaryPath.find_last_of("\\/");
    std::string filename = (pos == std::string::npos) ? primaryPath : primaryPath.substr(pos + 1);

    std::vector<std::string> tries;
    tries.push_back(primaryPath);
    tries.push_back("assets/" + filename);
    tries.push_back("resources/" + filename);
    tries.push_back(filename);

    for (const auto& p : tries) {
        Texture2D t = tryLoad(p);
        if (t.id != 0) return t;
    }
    return Texture2D{ 0 };
}

struct Game {
    Vector2 basePos;
    Vector2 baseSize;
    Vector2 topPos;
    Vector2 topSize;

    float cannonAngle;
    float cannonLength;
    float cannonThickness;

    float playerPower;
    std::vector<Projectile> projectiles;
    float shotCooldown;
    float shotTimer;

    std::vector<std::unique_ptr<EnemyBase>> enemies;
    float spawnTimer;
    float spawnInterval;

    int score;
    int lives;
    const int maxLives = 5;

    int destroyedCircles;
    int destroyedRects;
    const int winRequired = 10;
    bool won;

    Game() {
        baseSize.x = 140.0f; baseSize.y = 56.0f;
        topSize.x = 120.0f; topSize.y = 48.0f;

        basePos.x = 10.0f;
        basePos.y = (float)SCREEN_H - 60.0f - baseSize.y;

        topPos.x = basePos.x + (baseSize.x - topSize.x) * 0.5f;
        topPos.y = basePos.y - topSize.y;

        cannonAngle = 0.0f;
        cannonLength = 120.0f;
        cannonThickness = 12.0f;

        playerPower = 700.0f;
        shotCooldown = 0.20f;
        shotTimer = shotCooldown;

        spawnTimer = 0.0f;
        spawnInterval = 0.9f;

        score = 0;
        lives = maxLives;

        projectiles.resize(MAX_PROJECTILES);

        destroyedCircles = 0;
        destroyedRects = 0;
        won = false;
    }

    void Reset() {
        enemies.clear();
        for (auto& p : projectiles) p.active = false;
        spawnTimer = 0.0f;
        spawnInterval = 0.9f;
        shotTimer = shotCooldown;
        score = 0;
        lives = maxLives;

        basePos.x = 10.0f;
        basePos.y = (float)SCREEN_H - 60.0f - baseSize.y;
        topPos.x = basePos.x + (baseSize.x - topSize.x) * 0.5f;
        topPos.y = basePos.y - topSize.y;
        cannonAngle = 0.0f;
        playerPower = 700.0f;

        destroyedCircles = 0;
        destroyedRects = 0;
        won = false;
    }

    void SpawnRandomEnemy() {
        if (won) return;
        int t = RandInt(0, 3);
        if (t == 0) {
            float projSize = projectiles.front().radius * 2.0f;
            float ew = projSize * 2.0f;
            float eh = projSize * 1.8f;
            float maxW = baseSize.x - 4.0f;
            float maxH = baseSize.y - 4.0f;
            float minSize = fmax(projSize * 1.05f, 18.0f);
            ew = fmax(minSize, fmin(ew, maxW));
            eh = fmax(minSize, fmin(eh, maxH));

            float marginRight = 10.0f;
            float startX = (float)SCREEN_W + ew * 0.5f + marginRight;

            float minY = eh * 0.5f + 10.0f;
            float maxY = (float)SCREEN_H - GROUND_HEIGHT - eh * 0.5f - 10.0f;
            if (maxY < minY) maxY = minY;
            float y = RandFloat(minY, maxY);

            float sx = -RandFloat(80.0f, 220.0f);
            auto e = std::make_unique<EnemyRect>();

            e->pos = { startX, y };
            e->vel = { sx, 0.0f };
            e->rect.width = ew;
            e->rect.height = eh;
            e->rect.x = e->pos.x - ew * 0.5f;
            e->rect.y = e->pos.y - eh * 0.5f;
            e->alive = true;
            e->escaped = false;
            e->color = Color{ 50,200,50,255 };
            enemies.emplace_back(std::move(e));
            return;
        }
        else if (t == 1) {
            float enemyDia = 36.0f;
            float startX;
            float playerLeft = basePos.x;
            float playerRight = basePos.x + baseSize.x;
            float margin = 140.0f;

            int side = RandInt(0, 1);
            if (side == 1) {
                if (playerRight + margin < SCREEN_W - 20.0f) {
                    startX = RandFloat(playerRight + margin, (float)SCREEN_W - 20.0f);
                }
                else {
                    startX = RandFloat(playerRight + 10.0f, (float)SCREEN_W - 20.0f);
                }
            }
            else {
                int minX = 20;
                int maxX = (int)fmax(20.0f, playerLeft - margin);
                if (maxX <= minX) {
                    startX = RandFloat(playerRight + margin, (float)SCREEN_W - 20.0f);
                }
                else {
                    startX = (float)RandInt(minX, maxX);
                }
            }

            auto e = std::make_unique<EnemyCircle>();
            e->pos = { startX, -enemyDia };
            e->radius = enemyDia * 0.5f;
            e->vel = { -RandFloat(30.0f, 120.0f), RandFloat(20.0f, 80.0f) };
            e->restitution = RandFloat(0.75f, 0.95f);
            e->alive = true;
            e->escaped = false;
            e->color = Color{ 200,80,80,255 };
            float maxW = baseSize.x - 4.0f;
            float maxH = baseSize.y - 4.0f;
            float limit = fmin(maxW, maxH);
            if (e->radius * 2.0f > limit) {
                e->radius = limit * 0.5f - 1.0f;
            }
            enemies.emplace_back(std::move(e));
            return;
        }
        else {
            float enemyDia = 36.0f;
            float startX = 0.0f;
            float playerLeft = basePos.x;
            float playerRight = basePos.x + baseSize.x;
            float minX = 20.0f;
            float maxX = (float)SCREEN_W - 20.0f;
            int attempts = 0;
            do {
                startX = RandFloat(minX, maxX);
                attempts++;
                if (attempts > 10) break;
            } while (startX >= playerLeft && startX <= playerRight);

            if (startX >= playerLeft && startX <= playerRight) {
                if (playerRight + 40.0f < SCREEN_W - 20.0f) startX = RandFloat(playerRight + 20.0f, (float)SCREEN_W - 20.0f);
                else startX = RandFloat(20.0f, fmax(20.0f, playerLeft - 20.0f));
            }

            auto e = std::make_unique<EnemyFall>();
            e->pos = { startX, -enemyDia };
            e->radius = enemyDia * 0.5f;
            e->vel = { RandFloat(-20.0f, 20.0f), RandFloat(20.0f, 140.0f) };
            e->restitution = 0.0f;
            e->alive = true;
            e->escaped = false;
            e->color = Color{ 200,120,50,255 };
            float maxW = baseSize.x - 4.0f;
            float maxH = baseSize.y - 4.0f;
            float limit = fmin(maxW, maxH);
            if (e->radius * 2.0f > limit) {
                e->radius = limit * 0.5f - 1.0f;
            }
            enemies.emplace_back(std::move(e));
            return;
        }
    }

    void HandleInput() {
        if (won) {
            if (IsKeyPressed(KEY_R)) Reset();
            return;
        }

        float dt = GetFrameTime();
        if (IsKeyDown(KEY_UP)) cannonAngle += 90.0f * dt;
        if (IsKeyDown(KEY_DOWN)) cannonAngle -= 90.0f * dt;
        cannonAngle = std::clamp(cannonAngle, -10.0f, 90.0f);

        if (IsKeyDown(KEY_RIGHT)) playerPower += 500.0f * dt;
        if (IsKeyDown(KEY_LEFT)) playerPower -= 500.0f * dt;
        playerPower = std::clamp(playerPower, 200.0f, 1600.0f);

        shotTimer += dt;
        if (IsKeyPressed(KEY_SPACE) && shotTimer >= shotCooldown) {
            Vector2 tip = CannonTip();
            bool fired = false;
            for (auto& p : projectiles) {
                if (!p.active) {
                    p.Fire(tip, cannonAngle, playerPower);
                    fired = true;
                    break;
                }
            }
            if (fired) {
                shotTimer = 0.0f;
            }
        }
    }

    Vector2 CannonPivot() const {
        return { topPos.x + topSize.x * 0.5f, topPos.y + topSize.y * 0.5f };
    }
    Vector2 CannonTip() const {
        float a = cannonAngle * DEG2RAD;
        Vector2 pivot = CannonPivot();
        Vector2 tip = { pivot.x + cosf(a) * cannonLength, pivot.y - sinf(a) * cannonLength };
        return tip;
    }

    void Update(float dt) {
        if (!won) {
            spawnTimer += dt;
            if (spawnTimer >= spawnInterval) {
                spawnTimer = 0.0f;
                SpawnRandomEnemy();
            }
        }

        for (auto& p : projectiles) p.Update(dt);
        for (auto& e : enemies) if (e->alive) e->Update(dt);

        for (auto& p : projectiles) {
            if (!p.active) continue;
            for (auto& e : enemies) {
                if (!e->alive) continue;
                if (e->CheckCollision(p)) {
                    if (EnemyCircle* ec = dynamic_cast<EnemyCircle*>(e.get())) {
                        destroyedCircles++;
                    }
                    else if (EnemyRect* er = dynamic_cast<EnemyRect*>(e.get())) {
                        destroyedRects++;
                    }

                    e->alive = false;
                    p.active = false;
                    score += 100;
                    break;
                }
            }
        }

        if (!won && destroyedCircles >= winRequired && destroyedRects >= winRequired) {
            won = true;
        }

        Rectangle playerRect = { basePos.x, basePos.y, baseSize.x, baseSize.y };

        for (auto& e : enemies) {
            if (!e->alive || e->escaped) continue;

            bool touchedPlayer = false;
            bool crossedLeft = e->OutOfBoundsLeft();

            if (EnemyCircle* ec = dynamic_cast<EnemyCircle*>(e.get())) {
                if (CircleRectColl(ec->pos, ec->radius, playerRect)) touchedPlayer = true;
            }
            else if (EnemyRect* er = dynamic_cast<EnemyRect*>(e.get())) {
                if (CheckCollisionRecs(er->rect, playerRect)) touchedPlayer = true;
            }

            if (touchedPlayer || crossedLeft) {
                e->escaped = true;
                e->alive = false;
                lives--;
                if (lives < 0) lives = 0;
            }
        }

        enemies.erase(std::remove_if(enemies.begin(), enemies.end(),
            [](const std::unique_ptr<EnemyBase>& e) {
                return (!e->alive) || e->IsCompletelyOffscreen();
            }), enemies.end());
    }

    void Draw(const Texture2D& playerTex, const Texture2D& topTex, const Texture2D& enemyRectTex, const Texture2D& enemyCircleTex, const Texture2D& cannonTex, const Texture2D& projTex, const Texture2D& sueloTex, const Texture2D& fondoTex) const {
        if (fondoTex.id != 0) {
            Rectangle src = { 0.0f, 0.0f, (float)fondoTex.width, (float)fondoTex.height };
            Rectangle dest = { 0.0f, 0.0f, (float)SCREEN_W, (float)SCREEN_H };
            Vector2 origin = { 0.0f, 0.0f };
            DrawTexturePro(fondoTex, src, dest, origin, 0.0f, WHITE);
        }
        else {
            ClearBackground(Color{ 120,150,200,255 });
        }

        float groundY = (float)SCREEN_H - GROUND_HEIGHT;
        if (sueloTex.id != 0) {
            Rectangle srcG = { 0.0f, 0.0f, (float)sueloTex.width, (float)sueloTex.height };
            Rectangle destG = { 0.0f, groundY, (float)SCREEN_W, (float)GROUND_HEIGHT };
            Vector2 originG = { 0.0f, 0.0f };
            DrawTexturePro(sueloTex, srcG, destG, originG, 0.0f, WHITE);
        }
        else {
            DrawRectangle(0, (int)groundY, SCREEN_W, (int)GROUND_HEIGHT, GRAY);
        }

        Rectangle baseDest = { basePos.x, basePos.y, baseSize.x, baseSize.y };
        if (playerTex.id != 0) {
            Rectangle src = { 0.0f, 0.0f, (float)playerTex.width, (float)playerTex.height };
            Vector2 origin = { 0.0f, 0.0f };
            DrawTexturePro(playerTex, src, baseDest, origin, 0.0f, WHITE);
        }
        else {
            DrawRectangleRec(baseDest, Color{ 190,255,50,255 });
        }

        Vector2 pivot = CannonPivot();

        if (cannonTex.id != 0) {
            float tipCropFactor = 0.88f;
            Rectangle srcBarrel = { 0.0f, 0.0f, (float)cannonTex.width * tipCropFactor, (float)cannonTex.height };
            Rectangle destBarrel = { pivot.x, pivot.y - cannonThickness * 0.5f, cannonLength * tipCropFactor, cannonThickness };
            Vector2 origin = { 0.0f, cannonThickness * 0.5f };
            DrawTexturePro(cannonTex, srcBarrel, destBarrel, origin, -cannonAngle, WHITE);
        }
        else {
            Rectangle destBarrel = { pivot.x, pivot.y - cannonThickness * 0.5f, cannonLength, cannonThickness };
            Vector2 originBarrel = { 0.0f, cannonThickness * 0.5f };
            DrawRectanglePro(destBarrel, originBarrel, -cannonAngle, Color{ 20,120,30,255 });
        }

        if (topTex.id != 0) {
            Rectangle src = { 0.0f, 0.0f, (float)topTex.width, (float)topTex.height };
            Rectangle dest = { topPos.x, topPos.y, topSize.x, topSize.y };
            Vector2 origin = { 0.0f, 0.0f };
            DrawTexturePro(topTex, src, dest, origin, 0.0f, WHITE);
        }
        else {
            DrawRectangleV(topPos, topSize, Color{ 30,160,40,255 });
        }

        for (const auto& p : projectiles) p.Draw(projTex);

        for (const auto& e : enemies) {
            if (EnemyCircle* ec = dynamic_cast<EnemyCircle*>(e.get())) {
                ec->Draw(enemyCircleTex);
            }
            else {
                e->Draw(enemyRectTex);
            }
        }

        DrawText(TextFormat("Angle: %.1f deg", cannonAngle), 10, 10, 18, BLACK);
        DrawText(TextFormat("Power (vel init): %.0f", playerPower), 10, 34, 18, BLACK);
        DrawText(TextFormat("Score: %d", score), SCREEN_W - 260, 10, 20, BLACK);
        DrawText(TextFormat("Lives: %d / %d", lives, maxLives), SCREEN_W - 260, 34, 18, RED);

        int remainCircles = winRequired - destroyedCircles;
        int remainRects = winRequired - destroyedRects;
        if (remainCircles < 0) remainCircles = 0;
        if (remainRects < 0) remainRects = 0;

        DrawText(TextFormat("Enemigos Voladores: %d", remainCircles), SCREEN_W - 360, 64, 16, BLACK);
        DrawText(TextFormat("Enemigos de tierra: %d", remainRects), SCREEN_W - 360, 84, 16, BLACK);

        if (won) {
            DrawRectangle(0, 0, SCREEN_W, SCREEN_H, Fade(BLACK, 0.55f));
            DrawText("VICTORIA! Eliminaste al menos 10 enemigos de cada tipo.", 60, SCREEN_H / 2 - 20, 22, RAYWHITE);
            DrawText("Press R to restart or ESC to exit", 200, SCREEN_H / 2 + 14, 18, LIGHTGRAY);
        }
    }
};

int main() {
    InitWindow(SCREEN_W, SCREEN_H, "Operacion: Furia Cinetica - Jugador izquierda");
    SetTargetFPS(60);
    srand((unsigned int)time(nullptr));

    std::string path_player = R"(C:\Users\santino\Downloads\Raylib-vs2022 Limpio (1)\Raylib-vs2022 Limpio\tank.png)";
    std::string path_top = R"(C:\Users\santino\Downloads\Raylib-vs2022 Limpio (1)\Raylib-vs2022 Limpio\tank2.png)";
    std::string path_cannon = R"(C:\Users\santino\Downloads\Raylib-vs2022 Limpio (1)\Raylib-vs2022 Limpio\tank3.png)";
    std::string path_erect = R"(C:\Users\santino\Downloads\Raylib-vs2022 Limpio (1)\Raylib-vs2022 Limpio\enemy.png)";
    std::string path_ecirc = R"(C:\Users\santino\Downloads\Raylib-vs2022 Limpio (1)\Raylib-vs2022 Limpio\enemy2.png)";
    std::string path_proj = R"(C:\Users\santino\Downloads\Raylib-vs2022 Limpio (1)\Raylib-vs2022 Limpio\proyectil.png)";
    std::string path_suelo = R"(C:\Users\santino\Downloads\Raylib-vs2022 Limpio (1)\Raylib-vs2022 Limpio\suelo.png)";
    std::string path_fondo = R"(C:\Users\santino\Downloads\Raylib-vs2022 Limpio (1)\Raylib-vs2022 Limpio\fondo.png)";

    Texture2D playerTex = LoadTextureWithFallback(path_player);
    Texture2D topTex = LoadTextureWithFallback(path_top);
    Texture2D cannonTex = LoadTextureWithFallback(path_cannon);
    Texture2D enemyRectTex = LoadTextureWithFallback(path_erect);
    Texture2D enemyCircleTex = LoadTextureWithFallback(path_ecirc);
    Texture2D projTex = LoadTextureWithFallback(path_proj);
    Texture2D sueloTex = LoadTextureWithFallback(path_suelo);
    Texture2D fondoTex = LoadTextureWithFallback(path_fondo);

    auto anyTextureMissing = [&]() -> bool {
        return !(playerTex.id && topTex.id && cannonTex.id && enemyRectTex.id && enemyCircleTex.id && projTex.id && sueloTex.id && fondoTex.id);
        };

    bool loadingOK = !anyTextureMissing();
    while (!loadingOK) {
        BeginDrawing();
        ClearBackground(RAYWHITE);
        DrawText("FALTAN SPRITES O NO SE CARGARON CORRECTAMENTE", 60, SCREEN_H / 2 - 48, 22, RED);
        DrawText("Asegurate de que existan los archivos en las rutas indicadas.", 60, SCREEN_H / 2 - 20, 14, DARKGRAY);
        DrawText("Presiona R para reintentar (busca en rutas absolutas y en assets/ o resources/), ESC para salir.", 60, SCREEN_H / 2 + 6, 14, DARKGRAY);
        DrawText("Archivos buscados:", 60, SCREEN_H / 2 + 36, 12, BLACK);
        int y = SCREEN_H / 2 + 56;
        if (!playerTex.id) { DrawText(TextFormat(" - %s", path_player.c_str()), 66, y, 10, BLACK); y += 16; }
        if (!topTex.id) { DrawText(TextFormat(" - %s", path_top.c_str()), 66, y, 10, BLACK); y += 16; }
        if (!cannonTex.id) { DrawText(TextFormat(" - %s", path_cannon.c_str()), 66, y, 10, BLACK); y += 16; }
        if (!enemyRectTex.id) { DrawText(TextFormat(" - %s", path_erect.c_str()), 66, y, 10, BLACK); y += 16; }
        if (!enemyCircleTex.id) { DrawText(TextFormat(" - %s", path_ecirc.c_str()), 66, y, 10, BLACK); y += 16; }
        if (!projTex.id) { DrawText(TextFormat(" - %s", path_proj.c_str()), 66, y, 10, BLACK); y += 16; }
        if (!sueloTex.id) { DrawText(TextFormat(" - %s", path_suelo.c_str()), 66, y, 10, BLACK); y += 16; }
        if (!fondoTex.id) { DrawText(TextFormat(" - %s", path_fondo.c_str()), 66, y, 10, BLACK); y += 16; }

        EndDrawing();

        if (WindowShouldClose()) {
            if (playerTex.id) UnloadTexture(playerTex);
            if (topTex.id) UnloadTexture(topTex);
            if (cannonTex.id) UnloadTexture(cannonTex);
            if (enemyRectTex.id) UnloadTexture(enemyRectTex);
            if (enemyCircleTex.id) UnloadTexture(enemyCircleTex);
            if (projTex.id) UnloadTexture(projTex);
            if (sueloTex.id) UnloadTexture(sueloTex);
            if (fondoTex.id) UnloadTexture(fondoTex);
            CloseWindow();
            return 0;
        }

        if (IsKeyPressed(KEY_R)) {
            if (playerTex.id) { UnloadTexture(playerTex); playerTex = Texture2D{ 0 }; }
            playerTex = LoadTextureWithFallback(path_player);

            if (topTex.id) { UnloadTexture(topTex); topTex = Texture2D{ 0 }; }
            topTex = LoadTextureWithFallback(path_top);

            if (cannonTex.id) { UnloadTexture(cannonTex); cannonTex = Texture2D{ 0 }; }
            cannonTex = LoadTextureWithFallback(path_cannon);

            if (enemyRectTex.id) { UnloadTexture(enemyRectTex); enemyRectTex = Texture2D{ 0 }; }
            enemyRectTex = LoadTextureWithFallback(path_erect);

            if (enemyCircleTex.id) { UnloadTexture(enemyCircleTex); enemyCircleTex = Texture2D{ 0 }; }
            enemyCircleTex = LoadTextureWithFallback(path_ecirc);

            if (projTex.id) { UnloadTexture(projTex); projTex = Texture2D{ 0 }; }
            projTex = LoadTextureWithFallback(path_proj);

            if (sueloTex.id) { UnloadTexture(sueloTex); sueloTex = Texture2D{ 0 }; }
            sueloTex = LoadTextureWithFallback(path_suelo);

            if (fondoTex.id) { UnloadTexture(fondoTex); fondoTex = Texture2D{ 0 }; }
            fondoTex = LoadTextureWithFallback(path_fondo);

            loadingOK = !anyTextureMissing();
            if (loadingOK) break;
        }
        if (IsKeyPressed(KEY_ESCAPE)) {
            if (playerTex.id) UnloadTexture(playerTex);
            if (topTex.id) UnloadTexture(topTex);
            if (cannonTex.id) UnloadTexture(cannonTex);
            if (enemyRectTex.id) UnloadTexture(enemyRectTex);
            if (enemyCircleTex.id) UnloadTexture(enemyCircleTex);
            if (projTex.id) UnloadTexture(projTex);
            if (sueloTex.id) UnloadTexture(sueloTex);
            if (fondoTex.id) UnloadTexture(fondoTex);
            CloseWindow();
            return 0;
        }
    }

    if (playerTex.id) SetTextureFilter(playerTex, TEXTURE_FILTER_BILINEAR);
    if (topTex.id) SetTextureFilter(topTex, TEXTURE_FILTER_BILINEAR);
    if (cannonTex.id) SetTextureFilter(cannonTex, TEXTURE_FILTER_BILINEAR);
    if (enemyRectTex.id) SetTextureFilter(enemyRectTex, TEXTURE_FILTER_BILINEAR);
    if (enemyCircleTex.id) SetTextureFilter(enemyCircleTex, TEXTURE_FILTER_BILINEAR);
    if (projTex.id) SetTextureFilter(projTex, TEXTURE_FILTER_BILINEAR);
    if (sueloTex.id) SetTextureFilter(sueloTex, TEXTURE_FILTER_BILINEAR);
    if (fondoTex.id) SetTextureFilter(fondoTex, TEXTURE_FILTER_BILINEAR);

    Game game;

    while (!WindowShouldClose()) {
        game.HandleInput();
        float dt = GetFrameTime();
        game.Update(dt);

        BeginDrawing();
        ClearBackground(RAYWHITE);
        game.Draw(playerTex, topTex, enemyRectTex, enemyCircleTex, cannonTex, projTex, sueloTex, fondoTex);

        if (!game.won && game.lives <= 0) {
            DrawRectangle(0, 0, SCREEN_W, SCREEN_H, Fade(BLACK, 0.55f));
            DrawText("GAME OVER - Perdiste todas las vidas", 60, SCREEN_H / 2 - 20, 22, RAYWHITE);
            DrawText("Press R to restart or ESC to exit", 200, SCREEN_H / 2 + 14, 18, LIGHTGRAY);
            if (IsKeyPressed(KEY_R)) game.Reset();
        }
        EndDrawing();
    }

    if (playerTex.id != 0) UnloadTexture(playerTex);
    if (topTex.id != 0) UnloadTexture(topTex);
    if (cannonTex.id != 0) UnloadTexture(cannonTex);
    if (enemyRectTex.id != 0) UnloadTexture(enemyRectTex);
    if (enemyCircleTex.id != 0) UnloadTexture(enemyCircleTex);
    if (projTex.id != 0) UnloadTexture(projTex);
    if (sueloTex.id != 0) UnloadTexture(sueloTex);
    if (fondoTex.id != 0) UnloadTexture(fondoTex);

    CloseWindow();
    return 0;
}
